package com.example.app

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.app.ui.admin.AdminActivity
import com.example.app.ui.user.UserActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Mengubah warna status bar menggunakan colorPrimaryDark
        val statusBarColor = ContextCompat.getColor(this, R.color.colorPrimaryDark)
        window.statusBarColor = statusBarColor

        // Logic for checking role can go here
        val userRole = "user" // For demonstration purpose
        when (userRole) {
            "admin" -> {
                val intent = Intent(this, AdminActivity::class.java)
                startActivity(intent)
            }
            "user" -> {
                val intent = Intent(this, UserActivity::class.java)
                startActivity(intent)
            }
        }
    }
}
