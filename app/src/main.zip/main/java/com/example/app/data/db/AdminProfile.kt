package com.example.app.data.db

data class AdminProfile(
    val id: Int,
    val name: String,
    val email: String,
    val password: String,
)