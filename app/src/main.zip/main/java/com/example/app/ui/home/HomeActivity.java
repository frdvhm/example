package com.example.app.ui.home;

import android.app.Activity;

public class HomeActivity extends Activity {
}
