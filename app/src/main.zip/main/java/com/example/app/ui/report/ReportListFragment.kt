package com.example.app.ui.report

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.app.data.db.DatabaseHelper
import com.example.app.data.db.Report
import com.example.app.databinding.FragmentReportListBinding

class ReportListFragment : Fragment() {

    private var _binding: FragmentReportListBinding? = null
    private val binding get() = _binding!!
    private lateinit var reportAdapter: ReportAdapter
    private val reportList: MutableList<Report> = mutableListOf()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentReportListBinding.inflate(inflater, container, false)
        setupRecyclerView()
        loadReports()
        return binding.root
    }

    private fun setupRecyclerView() {
        reportAdapter = ReportAdapter(
            reports = reportList,
            isAdmin = false, // Atur sesuai dengan jenis pengguna
            onEditClickListener = { report -> navigateToEditReport(report) },
            onDeleteClickListener = { report -> deleteReport(report) },
            onStatusChangeListener = { report, newStatus ->
                updateReportStatus(report, newStatus)
            }
        )

        binding.recyclerViewReports.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = reportAdapter
        }
    }

    private fun loadReports() {
        val dbHelper = DatabaseHelper(requireContext())
        val reports = dbHelper.getAllReports()

        reportList.clear()
        reportList.addAll(reports)
        reportAdapter.notifyDataSetChanged()
    }

    private fun navigateToEditReport(report: Report) {
        // Logika navigasi ke halaman edit
        val fragment = AdminEditReportFragment().apply {
            arguments = Bundle().apply {
                putInt("REPORT_ID", report.id)
            }
        }
        requireActivity().supportFragmentManager.beginTransaction()
            .replace(com.example.app.R.id.nav_host_fragment, fragment)
            .addToBackStack(null)
            .commit()
    }

    private fun deleteReport(report: Report) {
        val dbHelper = DatabaseHelper(requireContext())
        val rowsDeleted = dbHelper.deleteReport(report.id)
        if (rowsDeleted > 0) {
            reportList.remove(report)
            reportAdapter.notifyDataSetChanged()
        }
    }

    private fun updateReportStatus(report: Report, newStatus: String) {
        // Logika untuk memperbarui status laporan
        val dbHelper = DatabaseHelper(requireContext())
        val updatedRows = dbHelper.updateReport(
            id = report.id,
            photo = report.photo,
            description = report.description,
            location = report.location,
            contact = report.contact,
            address = report.address,
            status = newStatus,
        )
        if (updatedRows > 0) {
            loadReports()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
