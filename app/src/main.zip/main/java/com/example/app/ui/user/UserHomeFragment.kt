package com.example.app.ui.user

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.fragment.app.Fragment
import com.example.app.R

class UserHomeFragment : Fragment(R.layout.fragment_user_home) {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the fragment's layout
        return inflater.inflate(R.layout.fragment_user_home, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Button untuk membuka dialog
        val btnAddLocation: Button = view.findViewById(R.id.btnAddLocation)
        btnAddLocation.setOnClickListener {
            // Tampilkan dialog
            val dialog = UploadReportDialogFragment()
            dialog.show(parentFragmentManager, "UploadReportDialog")
        }
    }
}
